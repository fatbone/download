#!/bin/bash

function _get_n_line
{
    #default first line
    local index=$1
    if [[ ! "$index" =~ '^[0-9]+$' ]] ; then
        index=1
    fi
    cat | sed -n "${index}p"
}

function _default_select_action
{
    local mapFunc=$1
    local action="$2"
    local param="$3"
    if [ -z "$action" -o "$action" == "v" ] ; then
        local file="$(echo  "$menuList" | _get_n_line $param | $mapFunc 0)"
        echo "Opening $file..."
        vim "$file"
        return 0
    elif [ "$action" == "c" ] ; then
        local path="$(echo "$menuList" | _get_n_line $param | $mapFunc 0 | xargs dirname)"
        echo "Entering $path..."
        cd "$path"
        return 0
    elif [ "$action" = 'g' ] ; then
        #run change set
        local newFileList=$(echo "$menuList" | $mapFunc 0 | xargs -n 10 grep -il $param | $mapFunc 1)
        if [ -n "$newFileList" ] ; then
            echo "Grepping '$param' inside files"
            menuList="$newFileList"
        else
            echo "*** Cannot find any file"
        fi
    fi
    return 1
}

function _default_underlying_map {
    #0: map from item name to underlying
    #1: map from underlying to item name
    local dir=$1
    #no change
    cat
}


function _filter_menu_items {
    local newMenuList="$menuList"
    for f in $@
    do
        newMenuList=$(echo "$newMenuList" | grep -i $f)
        local succ=$?
        if [ -z "$newMenuList" -o $succ -ne 0 ] ; then
            echo "*** Filter result is empty for $@ ***"
            menuList="$newMenuList"
            return
        fi
    done

    if [ $# -gt 0 ] ; then
        echo "--------$@----------"
        menuList="$newMenuList"
    fi
}

# Show a menu and ask for input. If the user entered a valid choice,
function select_item {

menuList="$1"
local actionFunc=${2:-_default_select_action}
local mapFunc=${3:-_default_underlying_map}
local prompt=${4:-"Input [Number/[cg ] Text/q]: "}
local filters="$5"
local line

local originMenuList="$menuList"

while true ; do

    if [ -z "$menuList" ] ; then
        return 0
    fi

    _filter_menu_items $filters

    local numOfItems=$(echo "$menuList" | wc -l)
    local padWidth=${#numOfItems}

    if [ -n "$menuList" ] ; then
        local seq=1
        echo "$menuList" | while read line
        do
            printf "%*d) %s\n" $padWidth $seq "$line"
            seq=$((seq + 1))
        done
    fi
    echo -n "$prompt"
    read REPLY

    #echo "'$REPLY'"
    if [ -z "$REPLY" -o "$REPLY" == "q" ] ; then
        return 1
    elif [[ $REPLY =~ '^[1-9][0-9]*$' && $REPLY -le $(echo "$menuList" | wc -l) ]] ; then
    # call default action
        if $actionFunc $mapFunc "" ${REPLY} ; then
            return 0
        fi
    # quit
    elif [[ $REPLY =~ '^[a-z] +.*$' || $REPLY =~ '^[a-z]$' ]] ; then
        #echo "action triggered $REPLY"
        if $actionFunc $mapFunc "${REPLY:0:1}" "${REPLY:1}" ; then
            return 0
        fi
    # further filter items by names
    else
        if [ "$REPLY" == "#" ] ; then
            menuList="$originMenuList"
            filters="$(echo "$filters" | sed -e 's/ *[^ ]\+$//')"
        else
            filters="$filters $REPLY"
        fi
    fi
done

}

