#!/bin/bash

BASE_FOLDER="$PUMA_SRC_DIR"
DB_FILE="$BASE_FOLDER/.fuzzyfiles"

function _add_base
{
    cat | sed "s#^#$BASE_FOLDER/#g"
}

function _remove_base
{
    cat | sed "s#^$BASE_FOLDER/##"
}

function _cdf_underlying_map
{
    if [ $1 -eq 0 ] ; then
        _add_base
    else
        _remove_base
    fi
}

function cdf
{

# going to a folder whose path have the name, or the file name
if [ -z "$1" ] ; then
    echo "This command quickly view or cd the path of a file under $BASE_FOLDER"
    echo "Usage: $0 filters"
    echo "then use shortcut 'c' or 'v' enter foler or view file"
    return 1
fi

if [ $# -eq 1 -a "$1" == "init" ]; then
    echo "build/update index file $DB_FILE ..."
    find $BASE_FOLDER/ -type f -name '*.cpp' -or -name '*.hpp' -or -name '*.hcpp' -or -name '*.idl' | sort | rev | uniq -s 4 | rev  > $DB_FILE
    return 0
fi

fileList=''
paramters="$@"

# Create a list of files to display
if [ -n "$1" ] ; then
    fileList=$(grep -i $1 $DB_FILE | _remove_base )
fi

shift

for var in $@ ; do
    fileList=$(echo "$fileList" | grep -i $var)
done

if [ -t 1 ] ; then #output to terminal
    if [ -z "$fileList" ] ; then
        echo "cannot find file with filers '$paramters'"
        return 1
    fi
else #running in a pipe
    echo "$(echo "$fileList" | _add_base)"
    return 0
fi

# Set the prompt for the select command
select_item "$fileList" _default_select_action _cdf_underlying_map

}

