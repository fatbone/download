# Okay
# 情
#: W291:5
print 


#: W291+1
class Foo(object):
    
    bang = 12


#: W291+1:34
'''multiline
string with trailing whitespace'''   
