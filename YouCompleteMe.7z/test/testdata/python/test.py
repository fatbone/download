import os; os.path.join( os.path.dirname( __file__ ) )
